---
name: scope-mvp
description: Convert a newly released web hackathon problem statement into ranked acceptance criteria, a minimal scope, and an implementation plan under a strict time limit.
---

# Scope a hackathon MVP

1. Read `harness/TASK.md` and identify objective, users, inputs, outputs, restrictions, deadline, submission format, and scoring rubric. Ask only for missing blocking facts.
2. Write a table: `ID | user behavior | expected result | verification | priority P0/P1/P2`.
3. Mark P0 as all explicitly graded requirements and one end-to-end usable flow. Do not silently reinterpret the task.
4. Allocate time: ~15% analysis/setup, 55% implementation, 20% verification, 10% submission buffer; revise if a deadline is known.
5. Map requirements to route/component/API/data model, with mocked vs actual dependencies explicitly identified.
6. Start with one vertical slice that proves frontend and backend integration, then extend according to priority.
7. Add the checklist and chosen tradeoffs to `harness/RESULTS.md` (local only). Return the 3 highest-risk assumptions to the user.

---
name: verify-release
description: Perform end-of-hackathon quality gates on a Next.js site, collect reproducible evidence, review compliance, and prepare honest submission notes.
---

# Verify before release

1. Compare implemented behavior against every P0/P1 criterion in `harness/TASK.md`; mark pass, fail, or untested with evidence.
2. Run `npm run verify`, `npm run build`, and `npm run test:e2e` if browsers are available; retain command outputs or exact error messages.
3. Manually inspect desktop/mobile at narrow widths; check navigation, forms, error handling, APIs, empty data, and keyboard accessibility.
4. Search for hardcoded tokens, private data, silent mock fallbacks, console errors, unlicensed assets, and accidental tracked task text.
5. Read `docs/COMPLIANCE.md`, confirm public-source permissions and organizer rules. Do not publish private task statements or hidden judging material.
6. Create a concise handoff: URL/run command, implemented criteria, passing tests, known limitations, and any unverified claims.

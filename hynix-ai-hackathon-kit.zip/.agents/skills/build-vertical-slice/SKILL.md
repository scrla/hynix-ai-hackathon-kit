---
name: build-vertical-slice
description: Build a working end-to-end Next.js feature from a hackathon requirement, including input validation, API/data flow, responsive UI, and feedback states.
---

# Build a vertical slice

1. Pick one unimplemented P0 acceptance criterion from the task checklist.
2. Trace the entire user path: action → form/state → server endpoint or data source → rendered result.
3. Implement the minimum real behavior in `app/`, `lib/`, and route handlers. Use TypeScript types at boundaries. Distinguish mock from production data.
4. Make empty, loading, invalid-input, network-failure, and success states visible where relevant.
5. Ensure keyboard use, labels, contrast, and mobile layout; prefer semantic HTML over custom widgets.
6. Add a test covering the user-visible result and a failure case. Do not add packages unless needed.
7. Run `npm run verify`, inspect failures, fix before proceeding. Log the criterion and proof in `harness/RESULTS.md`.

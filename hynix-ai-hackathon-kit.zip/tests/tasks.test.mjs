import assert from "node:assert/strict";
import { test } from "node:test";
import { readFileSync } from "node:fs";

test("task input applies trim, whitespace normalization, and a 100-character limit", () => {
  const code = readFileSync(new URL("../lib/tasks.ts", import.meta.url), "utf8");
  assert.match(code, /input\.trim\(\)\.replace/);
  assert.match(code, /\.slice\(0, 100\)/);
});

test("server health route returns JSON", () => {
  const code = readFileSync(new URL("../app/api/health/route.ts", import.meta.url), "utf8");
  assert.match(code, /NextResponse\.json/);
});

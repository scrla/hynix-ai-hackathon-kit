# Competition compliance checklist

The user-supplied screenshot states that public repositories containing reusable guidance, skills, harnesses, templates, and code may be used, provided reused repositories remain public through the specified result notification period; private repository use and wholesale substitution by outside materials are not permitted. **This is a summary of the provided excerpt, not a full authoritative rules audit.**

- [ ] Confirm the latest official instructions and any constraints on AI tools, network use, dependencies, and submissions.
- [ ] Verify every referenced third-party repository is public and remains public for the required period.
- [ ] Record upstream URL, license, and adaptation in `docs/ATTRIBUTION.md`.
- [ ] Never copy private repos, challenge secrets, credentials, or unpublished assessment material into a public repository.
- [ ] Do not present a prebuilt unrelated template as solving the actual task; implement task-specific features after release.
- [ ] Check `.gitignore`, tracked files, and build output before push.
- [ ] Preserve legitimate work history, test evidence, and citations; do not fabricate provenance.
- [ ] Check final submission requirements independently of this kit.

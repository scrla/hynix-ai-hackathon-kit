# Architecture decisions

- Next.js App Router/React/TypeScript for a compact full-stack route + UI experience.
- Local React state for the demo; replace with persistence only if the released task requires it.
- CSS without a component library to reduce setup/runtime dependencies.
- `/api/health` checks that the web server API is reachable.
- Playwright smoke tests the visible journey; preflight checks project shape and secret-file ignore rules.
- `harness/TASK.md` and `harness/RESULTS.md` are deliberately gitignored; public examples explain their expected format.

For actual problems, first decide whether data persistence, authentication, external APIs, or AI inference is necessary. Add only the minimum required services and identify their failure modes.

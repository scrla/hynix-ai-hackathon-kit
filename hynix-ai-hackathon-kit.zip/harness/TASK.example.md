# Real task intake (copy to TASK.md locally)

> Keep actual task contents local unless the organizer explicitly permits public redistribution.

- Task summary:
- Required users / use case:
- Inputs and outputs:
- Must-have behavior:
- Forbidden behavior / technology:
- Evaluation rubric:
- Time limit and submission instructions:
- Data/API assets provided:
- Open questions:

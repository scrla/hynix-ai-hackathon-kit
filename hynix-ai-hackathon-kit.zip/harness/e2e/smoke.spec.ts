import { expect, test } from "@playwright/test";

test("demo task list is interactive", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByRole("heading", { name: "Build checklist" })).toBeVisible();
  await page.getByRole("textbox", { name: "새 작업" }).fill("Test task");
  await page.getByRole("button", { name: "Add task" }).click();
  const row = page.getByRole("listitem").filter({ hasText: "Test task" });
  await expect(row).toBeVisible();
  await row.getByRole("checkbox").check();
  await expect(row.getByRole("checkbox")).toBeChecked();
  await row.getByRole("button", { name: "Test task 삭제" }).click();
  await expect(row).toHaveCount(0);
});

test("health endpoint answers JSON", async ({ request }) => {
  const response = await request.get("/api/health");
  expect(response.ok()).toBeTruthy();
  expect(await response.json()).toEqual({ ok: true, service: "hackathon-kit" });
});

# Local verification log (copy to RESULTS.md)

| ID | Requirement | State (pass/fail/untested) | Evidence |
|---|---|---|---|
| P0-1 | Replace with real requirement | untested | — |

## Commands actually run

| Command | Result | Notes |
|---|---|---|

## Risks and limitations

- List honest limitations before submitting.

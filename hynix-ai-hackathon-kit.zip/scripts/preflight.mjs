import { existsSync, readFileSync } from "node:fs";

const required = ["AGENTS.md", "package.json", "app/page.tsx", "app/api/health/route.ts", ".agents/skills/scope-mvp/SKILL.md", "docs/COMPLIANCE.md"];
let failed = false;

for (const path of required) {
  if (!existsSync(new URL(`../${path}`, import.meta.url))) { console.error(`Missing ${path}`); failed = true; }
}

const major = Number(process.versions.node.split(".")[0]);
if (major < 20) { console.error("Node.js 20.9+ required"); failed = true; }

const gitignore = readFileSync(new URL("../.gitignore", import.meta.url), "utf8");
for (const pattern of [".env*", "harness/TASK.md", "harness/RESULTS.md"]) {
  if (!gitignore.includes(pattern)) { console.error(`Missing ignore rule ${pattern}`); failed = true; }
}

if (failed) process.exitCode = 1;
else console.log("Preflight checks passed.");
